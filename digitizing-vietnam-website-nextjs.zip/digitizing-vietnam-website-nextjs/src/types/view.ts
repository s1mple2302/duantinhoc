export type ViewType = "grid" | "list" | "table";
